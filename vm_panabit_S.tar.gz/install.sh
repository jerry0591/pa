tar xf PanabitOEM_TANGr5p8_20240202_Linux3.tar.gz
./PanabitOEM_TANGr5p8_20240202_Linux3/ipeinstall
cp -rf joskmc /etc/
chmod 755 /etc/joskmc
#修改下以port=xxx为指定端口
rpm -i ./openssl*
echo -n "Please inut webport:"
read webport
echo -n "please input sshport:"
read sshport
echo -n "please input data interface:"
read dataport
sed -i "/DATA_PORTS/d" /etc/PG.conf
echo "DATA_PORTS=\"${dataport}\"" >>/etc/PG.conf
echo "ssl=1
user=root
max_age=1
maxchld=200
charset=gb2312
dir=/usr/ramdisk/admin
certfile=/usr/ramdisk/admin/admin.pem
port=${webport}
" >/usr/panaetc/httpd.conf
echo "systemctl start sshd" >>/etc/rc.local
#指定以上端口
echo /etc/joskmc port ${webport} ${sshport} >>/etc/rc.local
sh /etc/rc.local

chmod 755 /etc/PG.conf
. ../etc/PG.conf

clmac=`floweye if list |grep ${ADMIN_PORT}|awk -F " " '{print $6}'`
floweye if set name=${ADMIN_PORT} zone=outside mode=0
. ../conf/ifadmin.conf

floweye nat addproxy name=wan1 addr=${ADMIN_IP} gateway=${GATEWAY} ifname=${ADMIN_PORT} clonemac=${clmac}
